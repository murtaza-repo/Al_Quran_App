import React, { useEffect, useRef, useState } from "react";
import quranLogo from "../img/MAZLogo.png";
import { AiFillPauseCircle, AiFillPlayCircle } from "react-icons/ai";
import {
  BiSolidFastForwardCircle,
  BiSolidVolumeFull,
  BiSolidVolumeLow,
  BiSolidVolumeMute,
} from "react-icons/bi";
import { TbRepeat, TbRepeatOff } from "react-icons/tb";

export const AudioPage = () => {
  const data = {
    titles: Array(30)
      .fill()
      .map((_, i) => {
        return `Quran Juz Sipara ${i + 1}`;
      }),
    audioSrc: Array(30)
      .fill()
      .map((_, i) => {
        return `https://firebasestorage.googleapis.com/v0/b/alquran5.appspot.com/o/QuranAudio%2FQuran%20Juz%20${
          i + 1
        }.mp3?alt=media`;
      }),
  };

  // const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(
    new Array(data?.audioSrc?.length).fill(0)
  );
  const [duration, setDuration] = useState(
    new Array(data?.audioSrc?.length).fill(0)
  );
  const [isPlaying, setIsPlaying] = useState(
    new Array(data?.audioSrc?.length).fill(false)
  );
  const [volume, setVolume] = useState(
    new Array(data?.audioSrc?.length).fill(1)
  );

  const [isRepeat, setIsRepeat] = useState(
    new Array(data?.audioSrc?.length).fill(false)
  );

  const [playBackRate, setPlayBackRate] = useState(
    new Array(data?.audioSrc?.length).fill(1)
  );

  const audioRef = useRef([]);

  const handlePlay = (index) => {
    audioRef.current?.map((audio) => audio.pause());

    setIsPlaying((prevIsPlaying) => {
      let newIsPlaying = [...prevIsPlaying];

      newIsPlaying = newIsPlaying.map((play) => false);
      newIsPlaying[index] = true;

      return newIsPlaying;
    });
    audioRef.current[index].play();
  };

  const handlePause = (index) => {
    audioRef.current[index].pause();
    setIsPlaying((prevIsPlaying) => {
      const newIsPlaying = [...prevIsPlaying];
      newIsPlaying[index] = false;
      return newIsPlaying;
    });
  };

  const handlePlayPause = (index) => {
    if (isPlaying[index]) {
      handlePause(index);
    } else {
      handlePlay(index);
    }
  };

  const handleBackward = (index) => {
    const newCurrentTime = [...currentTime];

    newCurrentTime[index] =
      parseFloat(audioRef.current[index].currentTime) - 10;

    audioRef.current[index].currentTime =
      parseFloat(audioRef.current[index].currentTime) - 10;
    setCurrentTime(newCurrentTime);
  };

  const handleRepeat = (index) => {
    audioRef.current[index].loop = !isRepeat[index];
    setIsRepeat((prevIsRepeat) => {
      let newIsRepeat = [...prevIsRepeat];

      newIsRepeat[index] = !prevIsRepeat[index];

      return newIsRepeat;
    });
  };

  const handlePlaybackRate = (index) => {
    audioRef.current[index].playbackRate =
      playBackRate[index] === 1 ? 1.5 : 1.5 ? 2 : 1.5;
    if (playBackRate[index] === 2) {
      audioRef.current[index].playbackRate = 1;
    }
    setPlayBackRate((previousPlayback) => {
      let newPlayBack = [...previousPlayback];

      newPlayBack[index] = previousPlayback[index] === 1 ? 1.5 : 1.5 ? 2 : 1.5;
      if (previousPlayback[index] === 2) {
        newPlayBack[index] = 1;
      }
      return newPlayBack;
    });
  };

  const handleForward = (index) => {
    const newCurrentTime = [...currentTime];
    newCurrentTime[index] =
      parseFloat(audioRef.current[index].currentTime) + 10;

    audioRef.current[index].currentTime =
      parseFloat(audioRef.current[index].currentTime) + 10;
    setCurrentTime(newCurrentTime);
  };

  const handleTimeUpdate = (index) => {
    const newCurrentTime = [...currentTime];
    newCurrentTime[index] = audioRef.current[index].currentTime;
    setCurrentTime(newCurrentTime);

    const newDuration = [...duration];
    newDuration[index] = audioRef.current[index].duration;
    setDuration(newDuration);
  };

  const handleSeek = (e, index) => {
    audioRef.current[index].currentTime = parseFloat(e.target.value);
    let newCurrentTime = [...currentTime];
    newCurrentTime[index] = parseFloat(e.target.value);
    setCurrentTime(newCurrentTime);
  };

  const handleVolumeChange = (event, index) => {
    let newVolume = [...volume];

    newVolume[index] = parseFloat(event.target.value);
    setVolume(newVolume);
    if (audioRef.current[index]) {
      audioRef.current[index].volume = parseFloat(event.target.value);
    }
  };

  function formatDuration(durationSeconds) {
    const minutes = Math.floor(durationSeconds / 60);
    const seconds = Math.floor(durationSeconds % 60);
    const formattedSeconds = seconds.toString().padStart(2, "0");
    return `${minutes}:${formattedSeconds}`;
  }

  // useEffect(() => {
  //   audioRef.current[currentIndex].addEventListener("timeupdate", handleTimeUpdate);
  //   return () => {
  //     audioRef.current[currentIndex].removeEventListener("timeupdate", handleTimeUpdate);
  //   };
  // }, []);

  return (
    <div className="audioBackground">
      <div className="container ">
        <div className="row justify-content-center">
          {data?.audioSrc?.map((src, index) => (
            <div
              className="col-12 col-sm-6 col-md-4 col-lg-3 mb-3 d-flex justify-content-center"
              style={{ color: "crimson" }}
              key={index}
            >
              <div className="player-card mt-3 mb-3">
                <img src={quranLogo} alt="Cover" />
                <h6 className="text-black text-start mt-2">
                  {data?.titles[index]}
                </h6>
                <input
                  type="range"
                  min="0"
                  max={duration[index]}
                  value={currentTime[index]}
                  onChange={(e) => handleSeek(e, index)}
                />

                <audio
                  ref={(element) => (audioRef.current[index] = element)}
                  onTimeUpdate={() => handleTimeUpdate(index)}
                  src={src}
                />

                <div className="track-duration">
                  <p>{formatDuration(currentTime[index])}</p>
                  <p>{formatDuration(duration[index])}</p>
                </div>

                <div className="d-flex justify-content-center mt-2 mb-3">
                  <button onClick={() => handleRepeat(index)}>
                    <span
                      className="material-symbols-rounded"
                      style={{ marginTop: "-5px" }}
                    >
                      {isRepeat[index] ? (
                        <TbRepeat size={22} />
                      ) : (
                        <TbRepeatOff size={22} />
                      )}
                    </span>
                  </button>
                  <button onClick={() => handleBackward(index)}>
                    <span className="material-symbols-rounded">
                      <BiSolidFastForwardCircle
                        size={30}
                        style={{ transform: "rotate(180deg)" }}
                      />
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      handlePlayPause(index);
                    }}
                  >
                    <span className="material-symbols-rounded">
                      {isPlaying[index] ? (
                        <AiFillPauseCircle size={30} />
                      ) : (
                        <AiFillPlayCircle size={30} />
                      )}
                    </span>
                  </button>

                  <button onClick={() => handleForward(index)}>
                    <span className="material-symbols-rounded">
                      <BiSolidFastForwardCircle size={30} />
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      handlePlaybackRate(index);
                    }}
                  >
                    <span
                      className="material-symbols-rounded"
                      style={{ marginTop: "-5px" }}
                    >
                      <small>x{playBackRate[index]}</small>
                    </span>
                  </button>
                </div>

                <div className="d-flex align-items-center">
                  {volume[index] > 0.5 && (
                    <BiSolidVolumeFull
                      style={{ cursor: "pointer" }}
                      color="#436EE6"
                      onClick={() => {
                        let newVolume = [...volume];

                        newVolume[index] = 0;
                        setVolume(newVolume);
                        if (audioRef.current[index]) {
                          audioRef.current[index].volume = 0;
                        }
                      }}
                      size={25}
                    />
                  )}
                  {volume[index] > 0 && volume[index] <= 0.5 && (
                    <BiSolidVolumeLow
                      style={{ cursor: "pointer" }}
                      color="#436EE6"
                      onClick={() => {
                        let newVolume = [...volume];

                        newVolume[index] = 0;
                        setVolume(newVolume);
                        if (audioRef.current[index]) {
                          audioRef.current[index].volume = 0;
                        }
                      }}
                      size={25}
                    />
                  )}
                  {volume[index] === 0 && (
                    <BiSolidVolumeMute
                      style={{ cursor: "pointer" }}
                      color="#436EE6"
                      onClick={() => {
                        let newVolume = [...volume];

                        newVolume[index] = 1;
                        setVolume(newVolume);
                        if (audioRef.current[index]) {
                          audioRef.current[index].volume = 1;
                        }
                      }}
                      size={25}
                    />
                  )}
                  <input
                    className="ms-2"
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume[index]}
                    onChange={(e) => handleVolumeChange(e, index)}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
